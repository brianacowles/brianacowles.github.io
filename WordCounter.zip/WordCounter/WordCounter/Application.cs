﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WordCounter
{
    public partial class Application : Form
    {
        public Application()
        {
            InitializeComponent();
        }
        

        public void button1_Click(object sender, EventArgs e)
        {
            //get user input
            string document = textBox1.Text;
            //split on quotes
            //make list
            List<string> quoteSplit = document.Split('"').ToList();
            
            List<string> noquotes = new List<string>();
            
            //add nonquotes to new list
            if (quoteSplit[0].Contains("\""))
            {
                for (int i = 1; i < quoteSplit.Count; i+=2)
                {
                    noquotes.Add(quoteSplit[i]);
                }
            }
            else
            {
                for (int i = 0; i < quoteSplit.Count; i+=2)
                {
                    noquotes.Add(quoteSplit[i]);
                }
            }

            //split on parenth
            string noquotesstring = string.Join("", noquotes.ToArray());
            List<string> parenthSplit = noquotesstring.Split('(', ')').ToList();
            List<string> noparenth = new List<string>();

            //put nonparenth in new list
            if (quoteSplit[0].Contains("("))
            {
                for (int i = 1; i < parenthSplit.Count; i+=2)
                {
                    noparenth.Add(parenthSplit[i]);
                }
            }
            else
            {
                for (int i = 0; i < parenthSplit.Count; i+=2)
                {
                    noparenth.Add(parenthSplit[i]);
                }
            }
            //split on space
            string wordstring = string.Join("", noparenth.ToArray());
            List<string> words = wordstring.Split(' ').ToList<string>();

            //count words>3
            int total = 0;
            for (int i = 0; i < words.Capacity; i++)
            {
                if (words[i].Length > 3)
                {
                    total++;

                }
            }
            
            textBox3.Text = total.ToString();
        }
        
    }
}
