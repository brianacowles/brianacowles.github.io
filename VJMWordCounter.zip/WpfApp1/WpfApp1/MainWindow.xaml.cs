﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WordCounter
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //Button
            countButton.Click += Button_Click;
        }

        public void Button_Click(object sender, EventArgs e)
        {
            //get user input
            string document = userInput.Text;
            //split on quotes
            //make list
            List<string> quoteSplit = document.Split('"').ToList();

            List<string> noquotes = new List<string>();

            if (document == "")
            {
                return;
            }

            //add nonquotes to new list
            if (quoteSplit[0] == "")
            {
                for (int i = 2; i < quoteSplit.Count; i += 2)
                {
                    noquotes.Add(quoteSplit[i]);
                }
            }
            else
            {
                for (int i = 0; i < quoteSplit.Count; i += 2)
                {
                    noquotes.Add(quoteSplit[i]);
                }
            }

            if (noquotes.Count == 0)
            {
                return;
            }

            //split on parenth
            string noquotesstring = string.Join("", noquotes.ToArray());
            List<string> parenthSplit = noquotesstring.Split('(', ')').ToList();
            List<string> noparenth = new List<string>();
            
            //put nonparenth in new list
            if (noquotes[0] == "")
            {
                for (int i = 2; i < parenthSplit.Count; i += 2)
                {
                    noparenth.Add(parenthSplit[i]);
                }
            }
            else
            {
                for (int i = 0; i < parenthSplit.Count; i += 2)
                {
                    noparenth.Add(parenthSplit[i]);
                }
            }

            //split on space
            string wordstring = string.Join("", noparenth.ToArray());
            List<string> words = wordstring.Split(' ').ToList<string>();

            //count words>3
            int total = 0;
            for (int i = 0; i < words.Count; i++)
            {
                if (words[i].Length > 3)
                {
                    total++;
                }
            }

            output.Text = total.ToString();
            return;
        }

    }
}
